# Changelog

## Unreleased

### Added
- Ground-up Claude Code development pack.
- Project operating instructions.
- Development constitution.
- Master specification.
- Roadmap.
- Continuity files.
- Research and ADR structure.
- Security and testing requirements.

### Not yet implemented
- Runtime
- Retrieval engine
- Indexing engine
- MCP server
- Event engine
- Git automation

# AI_BRAIN — Current State

## Project

AI_BRAIN

## Development Mode

Ground-up development with Claude Code

## Current Phase

Phase 0 — Architecture & Research

## Current Status

Foundation package prepared. Implementation has not started.

## Accepted Architecture

- Standalone Python application
- Obsidian vault as source of truth
- AI_BRAIN separate from the vault
- One unified MCP server
- Event-driven architecture
- Hybrid retrieval
- Semantic/structure-aware chunking
- Embeddings + vector retrieval
- Keyword/metadata retrieval
- Reranking
- SQLite for application metadata/state
- Qdrant or another evaluated vector store, subject to Phase 0 research
- Git/GitHub for version control and backup
- Provenance and knowledge lineage
- Duplicate detection
- Knowledge lifecycle/status
- Multi-LLM/provider abstraction
- Local-first options where practical

## Completed

- Project vision established
- Core architecture direction established
- Development constitution established
- Claude Code operating rules established
- Continuity strategy established
- Ground-up development pack created

## Not Yet Completed

- Technology research
- Final technology selections
- Detailed architecture
- Data model
- MCP tool contract
- Event model
- Security threat model
- Testing strategy
- Initial implementation

## Immediate Next Step

Begin Phase 0 technology research, starting with the language/runtime and project tooling.

## Important Constraint

Do not start production implementation until Phase 0 exit criteria are satisfied.

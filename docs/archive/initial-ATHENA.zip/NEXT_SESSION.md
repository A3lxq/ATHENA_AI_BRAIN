# AI_BRAIN — Next Session

## Start Here

Read, in order:

1. `CLAUDE.md`
2. `docs/DEVELOPMENT_CONSTITUTION.md`
3. `CURRENT_STATE.md`
4. `docs/00_MASTER_PROJECT_SPECIFICATION.md`
5. `docs/ROADMAP.md`
6. relevant files under `docs/research/` and `docs/adr/`

## Objective

Start Phase 0 technology research.

## First Research Topic

Evaluate the programming language/runtime and foundational development stack for AI_BRAIN.

The research must compare viable options rather than assuming Python.

At minimum evaluate:
- Python
- TypeScript/Node.js
- Go
- Rust

The final decision must be recorded as an ADR.

## Research requirements

For each candidate evaluate:
- ecosystem
- MCP support
- AI/RAG ecosystem
- filesystem/event tooling
- SQLite support
- vector database clients
- async/concurrency model
- type safety
- performance
- security
- deployment
- Linux/Kali compatibility
- maintainability
- developer productivity
- long-term viability

## Deliverables

- research document
- comparison matrix
- recommendation
- ADR if a decision is reached
- updated master specification
- updated current state

## Do not

- write production code,
- install large dependencies unnecessarily,
- commit secrets,
- silently alter accepted architecture.

# AI_BRAIN — Git Workflow

## Principles

Git provides:
- source control,
- recovery,
- auditability,
- reproducibility,
- knowledge backup.

## Repository model

The AI_BRAIN software repository is separate from the Obsidian knowledge vault repository.

The vault should have its own Git repository if it is to be backed up and versioned.

Do not mix application source and personal knowledge into one repository unless explicitly designed and reviewed.

## Commit policy

Commits should be:
- small,
- meaningful,
- related to one logical change,
- free of secrets,
- testable.

## Example

`feat(retrieval): add hybrid candidate retrieval`

## Automatic Git

AI_BRAIN may automate commits and pushes, but automation must:
- be configurable,
- detect failures,
- avoid destructive commands,
- never commit secrets,
- provide clear logs,
- allow dry-run mode,
- support manual review.

## Branching

The project may use:
- main
- feature branches
- release tags

Exact policy will be finalized after the initial repository setup.

## Backup

The knowledge vault should be pushed regularly to a private Git remote.

Never assume Git is a substitute for independent backup. A future backup strategy should consider multiple remotes or other storage where appropriate.

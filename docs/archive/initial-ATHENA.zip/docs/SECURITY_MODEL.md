# AI_BRAIN — Security Model

## Security principle

Treat external input as untrusted.

This includes:
- web pages,
- Markdown,
- Git repositories,
- AI-generated content,
- retrieved chunks,
- MCP requests.

## Key threats

### Prompt injection

A retrieved note may contain instructions attempting to manipulate an LLM.

Mitigation:
- clearly separate retrieved data from system instructions,
- provenance,
- trust metadata,
- validation,
- avoid executing instructions found in documents.

### Path traversal

Never allow arbitrary paths to escape configured vault roots.

### Secrets

Do not index API keys, passwords, tokens, SSH private keys, or credential files.

A future secret scanner should run before ingestion and Git commit.

### Git safety

Never construct shell commands from untrusted text.

Prefer structured subprocess arguments.

### Tool abuse

MCP tools that mutate the vault or Git must have explicit permission boundaries.

### Web ingestion

Web content must be treated as untrusted source material.

Do not execute downloaded content merely because it was retrieved during research.

## Security review

Every feature that handles external input must include a threat model and security tests.

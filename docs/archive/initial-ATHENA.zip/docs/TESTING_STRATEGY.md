# AI_BRAIN — Testing Strategy

## Testing layers

### Unit

Pure functions and isolated components.

### Integration

Filesystem, SQLite, vector database, embeddings, Git, and provider integrations.

### Contract

MCP tools and provider abstractions.

### Retrieval evaluation

Use a curated evaluation corpus containing:
- representative notes,
- questions,
- expected relevant documents/chunks,
- relevance judgments.

Track metrics such as:
- Recall@K
- Precision@K
- MRR
- nDCG where appropriate
- latency

### Security

Test:
- path traversal,
- malicious metadata,
- prompt injection,
- poisoned documents,
- unsafe shell/Git arguments,
- secrets leakage,
- unauthorized MCP operations.

### Recovery

Simulate:
- interrupted indexing,
- database failure,
- partial writes,
- Git failure,
- network failure,
- duplicate events,
- repeated jobs.

## Quality gate

A feature cannot be marked complete solely because a happy-path test passes.
